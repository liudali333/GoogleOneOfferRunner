/*
 * 作者 Sky | TG 群: Geminivip1
 * 扩展：Google One Offer Runner v1.0.0
 * 请勿删除本署名；二次分发请保留作者信息。
 */
/*
 * bg.js — MV3 service worker
 *
 * 全局协调者。因为结账弹窗是跨域 iframe，顶层 frame 和 iframe 是两套 content script、
 * 互不可见，所有跨 frame 的时序与判断都收在这里：
 *
 *    popup ──RUN──▶ bg ──ARM──▶ driver(顶层) ──点击──▶ hook 改 ear ──▶ Play 弹窗
 *                                                                        │
 *    popup ◀─日志── bg ◀──CHECKOUT_TEXT / BUY_RESULT── play.js(iframe) ◀──┘
 *                    └──0 元闸门判断──▶ CLICK_BUY / ABORT
 *
 * 顺带说明为什么不需要 Playwright：Playwright 那层「连 CDP、点坐标、读 iframe」
 * 在这里分别由 chrome.* API、DOM 事件、iframe 内独立 content script 承担。
 */

const CFG_KEY = 'ce.config';
const SESSION_KEY = 'ce.session';

const DEFAULT_SESSION = {
  running: false,
  layer: 0,
  phase: 'idle', // idle | armed | checkout | gating | buying | done | failed
  tabId: null,
  logs: [],
  lastResult: null,
};

async function getSession() {
  const d = await chrome.storage.session.get(SESSION_KEY);
  return Object.assign({}, DEFAULT_SESSION, d[SESSION_KEY] || {});
}

async function setSession(patch) {
  const s = await getSession();
  const next = Object.assign({}, s, patch);
  await chrome.storage.session.set({ [SESSION_KEY]: next });
  return next;
}

async function log(msg, lvl = 'info') {
  const s = await getSession();
  const line = `[${new Date().toLocaleTimeString('zh-CN', { hour12: false })}] ${lvl === 'ok' ? '✅' : lvl === 'warn' ? '⚠️' : lvl === 'err' ? '❌' : '·'} ${msg}`;
  const logs = s.logs.concat(line).slice(-300);
  await setSession({ logs });
  try {
    await chrome.runtime.sendMessage({ type: 'STATE_PUSH' });
  } catch (_) {}
  return line;
}

async function badge(text, color = '#2563eb') {
  try {
    await chrome.action.setBadgeText({ text });
    await chrome.action.setBadgeBackgroundColor({ color });
  } catch (_) {}
}

/** 给某个 tab 的所有 frame 广播（各 frame 的 content script 自己判断角色） */
async function broadcast(tabId, msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, msg);
  } catch (_) {
    return null;
  }
}

/** 只给某个 frame 发（sender.frameId 拿到的那个） */
async function sendToFrame(tabId, frameId, msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, msg, { frameId });
  } catch (_) {
    return null;
  }
}

/* ==================== 0 元闸门 ==================== */
/**
 * 原件第 1212 行的保护逻辑：
 *   弹窗文案里没有 0.00 / 免费 / Free 就绝不点订阅，避免 hook 没生效时真扣钱。
 * 这里实现成后台的唯一裁决点，play.js 只负责上报文本、执行点击。
 */
function zeroCostGate(text, cfg) {
  if (cfg.zeroCostGate === false) return { pass: true, reason: '闸门已手动关闭' };
  const t = String(text || '');
  const ok = t.includes('0.00') || t.includes('免费') || /free/i.test(t);
  return ok
    ? { pass: true, reason: '检测到 0.00 / 免费' }
    : { pass: false, reason: '弹窗未显示 0 元，已拦截（不点击订阅按钮）' };
}

/** 等标签页真正加载完成到某个地址（换 origin 后 content script 要重新注入，不能急） */
async function waitTab(tabId, re, timeout = 25000) {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    const t = await chrome.tabs.get(tabId).catch(() => null);
    if (t && re.test(t.url || '') && t.status === 'complete') return t;
    await new Promise((r) => setTimeout(r, 400));
  }
  return null;
}

/**
 * 方案页可能落在哪些 URL 上。
 * ⚠️ Google 会把 /plans 302 到 /settings?expand=upgrade ——
 * 所以绝不能拿 URL 当"到了没"的判据（老版本就是这样空转的）。
 */
const PLANS_RE = /one\.google\.com\/(plans|settings)/;

/** 轮询 ping，直到顶层 driver 应答（比等 URL、等 load 事件都可靠） */
async function waitDriver(tabId, timeout = 20000) {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    const r = await broadcast(tabId, { type: 'PING' });
    if (r && r.ready === true) return r;
    await new Promise((res) => setTimeout(res, 500));
  }
  return null;
}

/**
 * 保证标签页停在"能点方案"的页面上，并且 content script 已就绪。
 * ⚠️ 导航必须由 bg 做：content script 自己 location.href 会销毁自己的上下文，
 * await 之后的点击逻辑永远执行不到（"只导航、没反应"）。
 */
async function ensurePlansTab(tabId) {
  const t = await chrome.tabs.get(tabId).catch(() => null);
  if (t && PLANS_RE.test(t.url || '')) {
    await log(`已在方案页（${String(t.url).slice(0, 58)}），跳过导航`);
  } else {
    await log(`导航到方案页（当前: ${String((t && t.url) || '').slice(0, 66)}）`);
    await chrome.tabs.update(tabId, { url: 'https://one.google.com/plans?hl=zh-CN' });
  }

  // 真正的判据：driver 能不能应答，而不是 URL 长得像不像
  const ready = await waitDriver(tabId, 20000);
  if (ready) {
    await log(`driver 就绪（${String(ready.href || '').slice(0, 58)}）`, 'ok');
    await new Promise((r) => setTimeout(r, 700)); // 让 React 首屏把方案卡渲染出来
  } else {
    await log('20s 内 driver 没应答（可能被跳去登录/二次验证），仍尝试下发 ARM', 'warn');
  }
  return !!ready;
}

/* ==================== 主流程 ==================== */
async function startRun(layer) {
  const s = await getSession();
  if (s.running) {
    await log('已有任务在跑，先等它结束或点重置', 'warn');
    return { ok: false, reason: 'busy' };
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https:\/\/(one|play)\.google\.com\//.test(tab.url || '')) {
    await log('当前标签页不是 one.google.com，请先在目标标签页打开 https://one.google.com/plans', 'err');
    return { ok: false, reason: 'wrong-tab' };
  }

  await setSession({ running: true, layer, phase: 'armed', tabId: tab.id, logs: [], lastResult: null });
  await badge('…', '#f59e0b');
  await log(authorBanner());
  await log(`开始执行 L${layer}（${new Date().toLocaleString('zh-CN')}）`);

  // 不管当前在哪个页面（包括已经在 one.google.com 但不在 /plans），统一由 bg 负责走到方案页
  await ensurePlansTab(tab.id);

  const res = await broadcast(tab.id, { type: 'ARM', layer });
  if (!res || !res.ok) {
    await log('顶层 content script 没响应：确认已装扩展、并刷新过这个标签页', 'err');
    await setSession({ running: false, phase: 'failed' });
    await badge('✕', '#dc2626');
  }
  return { ok: true };
}

async function startCancel() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return { ok: false };
  await setSession({ running: true, phase: 'cancel', tabId: tab.id });
  await log('开始取消自动续订');
  await chrome.tabs.update(tab.id, { url: 'https://play.google.com/store/account/subscriptions?hl=zh-CN' });
  await new Promise((r) => setTimeout(r, 3000));
  await broadcast(tab.id, { type: 'CANCEL_GO' });
  return { ok: true };
}

/* ==================== 消息路由 ==================== */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string') return;

  const tabId = (sender.tab && sender.tab.id) || null;
  const frameId = typeof sender.frameId === 'number' ? sender.frameId : 0;

  switch (msg.type) {
    /* ---------- 来自 popup ---------- */
    case 'RUN': {
      startRun(msg.layer).then(sendResponse);
      return true;
    }
    case 'CANCEL': {
      startCancel().then(sendResponse);
      return true;
    }
    case 'RESET': {
      (async () => {
        await setSession({ ...DEFAULT_SESSION });
        await badge('', '#2563eb');
        sendResponse({ ok: true });
      })();
      return true;
    }
    case 'GET_STATE': {
      (async () => {
        const cfg = (await chrome.storage.local.get(CFG_KEY))[CFG_KEY] || {};
        const s = await getSession();
        sendResponse({ session: s, cfg });
      })();
      return true;
    }
    case 'OPEN_PLANS': {
      (async () => {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) await chrome.tabs.update(tab.id, { url: 'https://one.google.com/plans?hl=zh-CN' });
        sendResponse({ ok: true });
      })();
      return true;
    }

    /* ---------- 来自 content script ---------- */
    case 'LOG': {
      log(msg.msg, msg.lvl || 'info');
      sendResponse({ ok: true });
      return true;
    }

    case 'CHECKOUT_WAIT': {
      log('等 Play 结账弹窗出现…');
      sendResponse({ ok: true });
      return true;
    }

    case 'CHECKOUT_FRAME': {
      // 顶层看到 iframe 了，把「开始读弹窗」广播给所有 frame，checkout 角色自己接
      setSession({ phase: 'checkout' });
      log('结账 iframe 已挂载，通知 iframe 内脚本接管', 'ok');
      if (tabId != null) broadcast(tabId, { type: 'CHECKOUT_GO' });
      sendResponse({ ok: true });
      return true;
    }

    case 'CHECKOUT_FRAME_READY': {
      // iframe 自己报到了（可能是复用的旧 frame），补一次 CHECKOUT_GO
      if (tabId != null) sendToFrame(tabId, frameId, { type: 'CHECKOUT_GO' });
      sendResponse({ ok: true });
      return true;
    }

    case 'CHECKOUT_TEXT': {
      (async () => {
        const cfg = (await chrome.storage.local.get(CFG_KEY))[CFG_KEY] || {};
        const g = zeroCostGate(msg.text, cfg);
        await log(`弹窗文案: ${String(msg.text).slice(0, 180)}`);
        if (g.pass) {
          await log(`0 元闸门通过（${g.reason}），点击订阅`, 'ok');
          await setSession({ phase: 'buying' });
          if (tabId != null) await sendToFrame(tabId, frameId, { type: 'CLICK_BUY' });
        } else {
          await log(`${g.reason} — 已中止，没有花任何钱`, 'err');
          await setSession({ running: false, phase: 'failed', lastResult: { ok: false, reason: g.reason } });
          await badge('✕', '#dc2626');
        }
        sendResponse({ ok: true, pass: g.pass });
      })();
      return true;
    }

    case 'BUY_RESULT': {
      (async () => {
        const s = await getSession();
        if (msg.ok) {
          await log('本层订阅成功', 'ok');
          await setSession({ running: false, phase: 'done', lastResult: { ok: true, text: msg.text } });
          await badge('✓', '#16a34a');

          const cfg = (await chrome.storage.local.get(CFG_KEY))[CFG_KEY] || {};
          if (cfg.autoCancel === true) {
            // 开了这个开关就自动收尾；注意叠加多层时不该开
            await log('已开启「成功后自动取消续订」，10 秒后自动执行（叠层时会断掉下一层，慎用）', 'warn');
            setTimeout(() => {
              startCancel();
            }, 10000);
          } else if (s.layer && s.layer < 4) {
            await log('要叠下一层就直接在 popup 里点下一个 L 按钮；三层都完成后再点「取消续订」', 'info');
          }
        } else {
          await log(`订阅失败: ${String(msg.text || '').slice(0, 220)}`, 'err');
          if (/出了点问题|Something went wrong|无法更改|unable to change/i.test(String(msg.text || ''))) {
            await log(
              '这是 Play 服务端拒单的通用页，不是支付失败。看上面「抓包 … 错误码」那行才是真因；没有错误码就说明请求没到 Play（ear 没改写成功）',
              'warn'
            );
          }
          await setSession({ running: false, phase: 'failed', lastResult: { ok: false, text: msg.text } });
          await badge('✕', '#dc2626');
        }
        sendResponse({ ok: true });
      })();
      return true;
    }

    case 'NEED_NAV': {
      (async () => {
        const s = await getSession();
        const tid = tabId != null ? tabId : s.tabId;
        await log(`driver 报告不在方案页，由后台重新导航后继续 L${msg.layer || s.layer || '?'}`, 'warn');
        if (tid != null) {
          await ensurePlansTab(tid);
          await broadcast(tid, { type: 'ARM', layer: msg.layer || s.layer });
        }
        sendResponse({ ok: true });
      })();
      return true;
    }

    case 'PROBE': {
      (async () => {
        const codes = Array.isArray(msg.codes) ? msg.codes : [];
        const tail = String(msg.url || '').split('?')[0].slice(-46);
        if (codes.length) {
          await log(`抓包 ${msg.kind} ${msg.status} ${tail} → 错误码 ${codes.join(', ')}`, 'err');
        } else {
          // 没有标准错误码时，只把看起来像报错的片段打出来，避免刷屏
          const snip = String(msg.snippet || '');
          const hit = /error|错误|invalid|denied|UNAVAILABLE|PERMISSION/i.test(snip);
          await log(`抓包 ${msg.kind} ${msg.status} ${tail}${hit ? ' → ' + snip.replace(/\s+/g, ' ').slice(0, 260) : ''}`, hit ? 'warn' : 'info');
        }
        sendResponse({ ok: true });
      })();
      return true;
    }

    case 'INLINE_CARD_SAVED': {
      (async () => {
        const s = await getSession();
        await log('卡已内联保存，重新拉起 0 元结账弹窗', 'ok');
        if (s.tabId != null && s.layer) {
          await new Promise((r) => setTimeout(r, 1200));
          await broadcast(s.tabId, { type: 'ARM', layer: s.layer });
        }
        sendResponse({ ok: true });
      })();
      return true;
    }

    case 'CANCEL_RESULT': {
      (async () => {
        if (msg.ok) {
          await log(`取消续订完成${msg.already ? '（本来就是取消态）' : ''}`, 'ok');
          await badge('✓', '#16a34a');
        } else {
          await log(`取消续订失败: ${msg.reason || ''}`, 'err');
          await badge('✕', '#dc2626');
        }
        await setSession({ running: false, phase: 'idle', lastResult: { ok: !!msg.ok, text: msg.reason || '' } });
        sendResponse({ ok: true });
      })();
      return true;
    }

    case 'RUN_FAILED': {
      (async () => {
        await log(`L${msg.layer || '?'} 执行失败: ${msg.reason || ''}`, 'err');
        await setSession({ running: false, phase: 'failed', lastResult: { ok: false, reason: msg.reason } });
        await badge('✕', '#dc2626');
        sendResponse({ ok: true });
      })();
      return true;
    }

    default:
      return;
  }
});

/* 标签页关掉就把 running 复位，避免卡在 busy */
chrome.tabs.onRemoved.addListener(async (closedId) => {
  const s = await getSession();
  if (s.tabId === closedId) {
    await setSession({ running: false, phase: 'idle', tabId: null });
    await badge('', '#2563eb');
  }
});

/* ---------- 作者署名 ---------- */
const AUTHOR = { name: 'Sky', tg: 'Geminivip1', url: 'https://t.me/Geminivip1' };

function authorBanner() {
  return `Google One Offer Runner v1.1.0 · 作者 ${AUTHOR.name} · TG 群: ${AUTHOR.tg}`;
}

chrome.runtime.onInstalled.addListener(() => {
  log(authorBanner());
  log(`使用遇到问题可进 TG 群 ${AUTHOR.tg} 反馈`);
});
