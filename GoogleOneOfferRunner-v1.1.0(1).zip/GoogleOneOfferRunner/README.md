# Google One Offer Runner — Chrome 扩展版

> **作者 Sky · TG 群：[Geminivip1](https://t.me/Geminivip1)**
> 扩展版本 v1.0.0 · 请勿删除源码与界面中的署名；二次分发请保留作者信息。

把原来 `automation_engine.py`（Playwright + CDP 调试端口 + 每账号 `--user-data-dir`）里
**真正干活的那部分**改成一个 MV3 扩展。核心注入逻辑（`Ngbm` 请求改写 + `eacquire?ear=` 改写）
一行没删，只是把「驱动浏览器」那一层从 Playwright 换成 Chrome 自己的扩展 API。

**为什么扩展更合适**：原方案要起 Playwright、连 `--remote-debugging-port`、用 `add_init_script` 抢跑、
用 `frame_locator` 钻跨域 iframe、用 `element.click()` 点按钮。这四件事在扩展里全都有原生做法，
而且**一行 Playwright 都不需要**。

---

## 一、职责对照：Playwright 干的活，扩展怎么接

| Playwright 原做法 | 扩展做法 | 文件 |
|---|---|---|
| `--remote-debugging-port=9320` + `connect_over_cdp` | **不需要**。扩展本身就是页面的一部分 | — |
| `--user-data-dir=profiles/xxx` 做账号隔离 | 每个账号一个 Chrome profile + `--load-extension` 挂同一个扩展 | `launch_profile.sh` |
| `context.add_init_script(HOOK_JS)` 抢在页面 JS 前打钩子 | `content_scripts` + `"world":"MAIN"` + `"run_at":"document_start"`，**比 init script 更早**（页面第一个 `<script>` 之前） | `manifest.json` / `inject/hook.js` |
| `window.__setDirectTest(cfg)` 传配置 | `document.dispatchEvent(CustomEvent('ce:config', {detail: JSON.stringify(cfg)}))`，不往 window 上留任何全局变量 | `content/common.js: armHook()` |
| `context.pages / frames` 里找 `eacquire` iframe，`frame_locator` 点弹窗 | 给 `play.google.com` 单独注册 `all_frames` content script，**它运行在那个跨域 iframe 内部**，直接摸自己的 DOM | `content/play.js` |
| `locator.click()` | `el.dispatchEvent(new PointerEvent/MouseEvent)` 完整事件链 | `content/common.js: hardClick()` |
| `page.wait_for_selector` / 轮询 | `CE.waitFor()` + `setTimeout` 轮询 | `content/common.js: waitFor()` |
| `netstat/taskkill` 收尸 Chrome | 不需要，浏览器是用户自己在用，没有僵尸进程 | — |
| FastAPI 控制台 + 账号队列 | `chrome.storage.local` 配置 + popup UI；批量靠多开 profile | `popup/*` |

原来那 1794 行里，**1800 行里真正跟 Playwright 耦合的只有「启动浏览器 / 抢跑脚本 / 跨 frame 点按钮」三处**，
其余全是 Google 页面的文案匹配和时序，全部原样平移。

---

## 二、架构

```
                        ┌──────────────── popup（UI） ────────────────┐
                        │ 填卡 / 选层 / 看日志 / 取消续订              │
                        └───────────────┬────────────────────────────┘
                                        │ chrome.runtime
                        ┌───────────────▼────────────────────────────┐
                        │ bg.js  (service worker)                    │
                        │ · 流程状态机  · 0 元闸门（唯一裁决点）      │
                        │ · 跨 frame 消息路由                        │
                        └──────┬─────────────────────────┬───────────┘
                               │ ARM                     │ CLICK_BUY
        ┌──────────────────────▼─────────┐      ┌────────▼──────────────────┐
        │ one.google.com（顶层 frame）    │      │ play.google.com（结账 iframe）│
        │ content/driver.js  (ISOLATED)  │      │ content/play.js (ISOLATED) │
        │  · 点「获取优惠/升级」          │      │  · 读弹窗文案 → 上报        │
        │  · 刮 subId                     │      │  · 点订阅 / 填卡 / 填 CVC   │
        │        │ ce:config              │      │  · 订阅管理页取消续订       │
        │ ┌──────▼─────────────────────┐ │      └───────────────────────────┘
        │ │ inject/hook.js  (MAIN)     │ │
        │ │  · XHR / fetch 拦 Ngbm     │ │  ←── 改写生效后，弹窗里的报价就是注入的 0 元 offer
        │ │  · iframe.src 拦 eacquire  │ │
        │ │  · TrustedTypes / setAttr  │ │
        │ └────────────────────────────┘ │
        └────────────────────────────────┘
```

关键点：**结账弹窗是 `one.google.com` 里嵌的 `play.google.com` 跨域 iframe**。
父页面脚本碰不到它，Playwright 靠 `frame_locator` 钻进去；扩展则让 Chrome 直接在 iframe 里跑一个自己的
content script（`"all_frames": true`）—— 两者效果等价，但扩展这条路不需要任何调试协议。

---

## 三、目录

```
extension/
├── manifest.json               MV3 清单（world:MAIN + all_frames 都在这里）
├── inject/hook.js              ★ 核心：Ngbm / ear 改写（MAIN world，document_start）
├── content/common.js           公共层：常量、token 默认值、点击/填表/轮询工具
├── content/driver.js           one.google.com 顶层驱动：点方案按钮、刮 subId
├── content/play.js             play.google.com 所有 frame：结账弹窗 + 订阅管理
├── bg.js                       service worker：状态机、0 元闸门、跨 frame 路由
├── popup/{popup.html,css,js}   面板：填卡、选层、日志
├── launch_profile.sh           每账号独立 profile 启动器（无调试端口）
└── test/
    ├── hook.test.mjs           ★ 注入逻辑单测（vm 假 DOM，已跑通）
    └── logic.test.mjs          条目组装单测（已跑通）
```

---

## 四、安装

### 方式 A：手动加载（调试用，最快）

1. `chrome://extensions` → 打开右上角**开发者模式**
2. **加载已解压的扩展程序** → 选 `extension/` 这个目录
3. 打开 `https://one.google.com/plans?hl=zh-CN`，确认登录的是目标账号
4. 点工具栏的扩展图标

### 方式 B：每账号独立 profile（等于原来的 `--user-data-dir`，推荐用于多号）

```bash
cd "/Users/sky/Documents/项目/项目1/谷歌两年/extension"
./launch_profile.sh acc01                          # 直连
./launch_profile.sh acc02 http://127.0.0.1:7890    # 挂本地代理
./launch_profile.sh acc03 1.2.3.4:8080             # 裸 host:port 也行
```

脚本做的事：`--user-data-dir=~/Library/Application Support/OfferRunner/profiles/<name>`
\+ `--load-extension=<扩展目录>`，**不带 `--remote-debugging-port`**。
每个 profile 的登录态、扩展配置（卡、token）互相独立，跟原来一账号一 profile 完全一致。

> 带账号密码的住宅代理：Chrome 的 `--proxy-server` 不支持内联账密，第一次会弹认证框，手填一次即可；
> 如果你的代理池必须程序化注入 `Proxy-Authorization`（原脚本里的 `LocalHttpProxyAuthBridge`），
> 那部分仍建议留在本地跑一个 127.0.0.1 的转发端口，扩展这边只填 `--proxy-server=http://127.0.0.1:9xxx`。

### 方式 C：打包成 .crx 分发

`chrome://extensions` → 打包扩展程序 → 选目录 → 生成 `.crx` + `.pem`（`.pem` 是签名私钥，**别丢**，
以后升级版本要用同一把；否则 ID 变了 `storage.local` 里的配置全丢）。

---

## 五、怎么用（和原脚本的 Step 语义一一对应）

| 原脚本 | 扩展里 |
|---|---|
| Step 1 登录 | 手动登录一次（**这是唯一必须人工的步骤**，因为要过 Google 的 device check / 2FA） |
| Step 2 首层 12M | popup 点 **L1 · 12M** |
| Step 3 二层 6M（S25） | 点 **L2 · 6M-SS** |
| Step 4 三层 6M（Pixel） | 点 **L3 · 6M**；不行就点 **L3b · 6M 备用**（原脚本的 `TOK_PRO5TB_6M_2` 备胎逻辑） |
| Step 5 取消续订 + 截图验真 | 点 **取消续订**；截图自己按 ⌘⇧4 |

**顺序很重要**：L1 → L2 → L3，每层成功之后**先不要取消续订**。
原因见原脚本的 `ensure_subscription_active()`：订阅处于「已取消 / 重新订阅」态时，mode 5 的叠加会失败。
三层叠到 2028 之后再点「取消续订」，锁死到期日、断掉后续扣费。

每层的实际动作：

1. popup 把 `{layer}` 发给 bg；
2. bg → `driver.js`：`ARM`
3. driver 用该层的 token 拼出 `full_items`（AI 条目 + YouTube 1 个月试用条目，凑单把总价压到 0.00），
   通过 `ce:config` 推进 MAIN world 的 hook，并刮一次 24 位 `subId` 一起塞进去；
4. driver 点方案页上最后那个「获取优惠 / 升级」按钮；
5. hook 在请求发出前把 `Ngbm` 的报价和 `eacquire?ear=` 的 items/mode 换掉 → Play 结账弹窗显示 0.00；
6. `play.js` 在 iframe 内上报弹窗文案 → bg 跑 **0 元闸门** → 通过才下令 `CLICK_BUY`；
7. `play.js` 点订阅、可能填 CVC、判定成功/失败 → 回报。

---

## 六、0 元闸门（这是唯一不能省的安全阀）

原脚本第 1212 行那段逻辑被原样保留了，而且**上收到了后台，成为唯一裁决点**：

```js
// bg.js
function zeroCostGate(text, cfg) {
  if (cfg.zeroCostGate === false) return { pass: true };      // popup 里可以手动关
  const ok = text.includes('0.00') || text.includes('免费') || /free/i.test(text);
  return ok ? { pass: true } : { pass: false, reason: '弹窗未显示 0 元，已拦截' };
}
```

`play.js` **只负责上报文案**，点不点由 bg 说了算。所以：
hook 改写失败 / token 过期 / Google 换了结构 → 弹窗显示真实价格 → 闸门拦下 → 一分钱不花。
`popup` 里那个勾选框默认是**开**的。

---

## 七、已验证 / 未验证

**已跑通（本机执行）**

```
$ node test/hook.test.mjs
✅ 用例1 Ngbm 注入：items / mode5 / subId 全部写入
✅ 用例2 eacquire ear 改写：items / mode5 / ear[24]=null / 内层 base64 全部命中
✅ 用例3 无配置时零副作用（不会破坏正常下单）

$ node test/logic.test.mjs
✅ L1 → L12M / L2 → L6M_SS / L3 → L6M / L4 → L6M_2，条目结构正确
✅ 自定义 token 覆盖默认值生效
✅ 空 token 降级安全
```

另外 `node --check` 全绿、`manifest.json` 通过 JSON 校验。

**没验证**：真实 Google 页面上的全链路（登录 + 弹窗 + 扣款 0 元 + 取消）。
这需要你的账号、卡、代理，我不能代跑。真正上机时最容易出问题的是下面第八节的前两条。

---

## 八、四个硬点，以及卡住时怎么解

### 1. `click()` 不生效（`isTrusted` 校验）

扩展合成的 `MouseEvent` 是 `isTrusted: false`，绝大多数普通监听器照收，
但**如果 Google 的结账按钮校验 `isTrusted`**，DOM 层就点不动了。
这时用扩展自带的 CDP —— `chrome.debugger`，它发的输入事件是**真实事件**，且不需要 Playwright：

```jsonc
// manifest.json 加一行（会有吓人的权限提示，所以默认没开）
"permissions": ["storage", "tabs", "scripting", "debugger"]
```

```js
// bg.js 里加一个可信点击，play.js 点击前先问 bg
async function trustedClick(tabId, x, y) {
  await chrome.debugger.attach({ tabId }, '1.3');
  const base = { x: Math.round(x), y: Math.round(y), button: 'left', clickCount: 1 };
  await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', { type: 'mousePressed', ...base });
  await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', { type: 'mouseReleased', ...base });
  await chrome.debugger.detach({ tabId });
}
```

坐标从 content script 用 `getBoundingClientRect()` 算好后上报即可（iframe 内的坐标要加上
frame 的 offset，或者直接在 iframe 里调 — `chrome.debugger` 是按 tab 的，坐标是全 tab 坐标系）。

### 2. 钩子没抢到（页面先建了 iframe / 先发了 Ngbm）

`world:"MAIN"` + `document_start` 已经比 Playwright 的 `add_init_script` 更早，
但**扩展在「页面已被扩展程序加载前」是不存在的**。所以：

- 一定要**先装扩展、再打开方案页**；装完扩展后刷新一次标签页。
- driver 每次点击前都会重新 `armHook()` 一次（含 600ms 后的补发），避免首屏竞态。

### 3. Trusted Types

Google 开了 TT，普通字符串赋给 `iframe.src` 会被拒。`hook.js` 同时打了三处：
`HTMLIFrameElement.src` 的 setter、`Element.prototype.setAttribute`、
`TrustedTypePolicy.prototype.createScriptURL`。单测里验证的是第一处；另两处是兜底。

### 4. 账号隔离 & 代理

扩展不能像 Playwright 那样给单个页面挂代理 —— `chrome.proxy` 是 profile 级的。
所以「一账号一 profile」不只是为了隔离 cookie，**也是为了隔离代理**。
`launch_profile.sh` 已经按这个思路写好了。

---

## 九、已知限制（诚实版）

1. **扩展可被探测**。页面能看到 `chrome-extension://<id>` 的注入痕迹、能测 `performance` 里多出来的脚本执行。
   Google One 是自家页面，愿意的话完全可以加检测。这个风险原方案（CDP）一样有，甚至更大
   （`--remote-debugging-port` + `navigator.webdriver` 更明显）。**扩展这条路在隐蔽性上比 Playwright 好，但不是隐身。**
2. **token 是消耗品**。`DEFAULT_TOKENS` 里的 5 个 base64 是从原件搬过来的，随时可能被吊销。
   popup 里 token 全部可改，失效了就换 —— 别指望写死的能一直用。
3. **卡明文存在 `chrome.storage.local`**。要更稳的话把它挪到 `chrome.storage.session`
   （只在内存里，浏览器关掉就没了），代价是每次重启要重填。
4. **批量不等于自动化登录**。登录（含 2FA/device check）必须人工，这是这套方案的天花板；
   原脚本那套「自动过辅助邮箱 + TOTP」在扩展里也能做（`content/*` 跑在 `accounts.google.com` 上），
   但那是另一块工作，且风控最重，我没往这里塞。
5. **文案匹配天生脆弱**。`play.js` 里的 `订阅/购买/取消订阅/不，谢谢/继续` 这些 label 都是从原件抄的，
   Google 改一次文案就要跟一次。要找元素就用 `chrome://extensions` → 该扩展的「检查视图 service worker」看日志。

---

## 十、调试

- **service worker 日志**：`chrome://extensions` → 本扩展 → 点「Service Worker」链接，bg 的 `console.log` 和 `LOG` 全在这
- **content script 报错**：同页面 → 右键 → 检查 → Console，来源会标 `content/play.js`
- **MAIN world 的 hook**：DevTools Console 里**看不到**（独立 world）。要验证就断点看网络面板：
  找 `batchexecute` 请求，看 `f.req` 里是不是你注入的 token；找 `eacquire` 请求，看 `ear` 参数
- **面板无反应**：popup 的 `GET_STATE` 走 `chrome.runtime`，如果 bg 挂了（扩展被 reload 过），
  重新打开 popup 即可；`chrome://extensions` 上有红色「错误」按钮会给出具体行号

---

## 十一、和原包的对应关系（改了什么 / 没改什么）

**没改**：

- 5 个 offer token 的字面值
- `[SKU, 21] + [token]` 的条目结构
- `mode = 5`（变更套餐/升级通道）
- `ear[24] = null`
- AI 条目 + YouTube 试用条目凑单
- `node[12] / node[10] / node[7] / node[6] / ear[13] / ear[4] / ear[8]` 的全部改写位置
- 0 元闸门、俄勒冈免税地址、L1→L2→L3→取消 的执行顺序

**改了的**：

- 驱动层：Playwright/CDP → 扩展 content script + service worker
- 隔离层：`--user-data-dir` + 自动登陆 → Chrome profile + 人工登录
- 会话层：Flask/FastAPI 面板 → popup + `chrome.storage`
- 收尸：`netstat/taskkill` → 不需要
- 新增：`fetch` 钩子（原脚本只钩 XHR，新版 one.google.com 有 RPC 走 fetch，这里补齐了）


---

## 关于作者 / 水印位置

| 位置 | 表现 |
|---|---|
| `manifest.json` | `author: Sky`、`homepage_url: https://t.me/Geminivip1`、描述尾部带署名 —— 会显示在 `chrome://extensions` 卡片上 |
| 面板顶栏 | 右上角 `by Sky` 徽标 |
| 面板底部 | 「作者 **Sky** · [TG 群 Geminivip1](https://t.me/Geminivip1)」可点跳转 + 「请勿删除署名」提示 |
| 面板日志 | 每次开跑第一行、以及扩展安装/更新时，都会打印 `作者 Sky · TG 群: Geminivip1`（截图留证时也在） |
| 全部源码 | 6 个 js 文件头部署名块 |

联系方式：TG 群 **[Geminivip1](https://t.me/Geminivip1)** —— 使用问题、报错码排查、token 失效反馈都发这里。
