/*
 * 作者 Sky | TG 群: Geminivip1
 * 扩展：Google One Offer Runner v1.0.0
 * 请勿删除本署名；二次分发请保留作者信息。
 */
/*
 * inject/hook.js — MAIN world, document_start, all_frames
 *
 * 等价于原来 automation_engine.py 里 playwright 的
 *   context.add_init_script("window.__INIT_TEST=null;" + HOOK_JS)
 * 但比它更早（document_start 在页面任何一个 <script> 之前跑），
 * 而且不往 window 上留 __HOOK_INSTALLED / __setDirectTest / __capturedSubId 这些可被探测的全局变量。
 *
 * 职责只有两件：
 *   1) 拦截 one.google.com 的 batchexecute 请求（RPC id = Ngbm），把报价条目换成注入的 offer token
 *   2) 拦截 /eacquire/multiline?ear=... 的 iframe / window.open，把 ear 参数里的 items 与 mode 换掉
 *
 * 配置由 ISOLATED world 的 content script 通过 document 上的 CustomEvent('ce:config') 送进来，
 * detail 用 JSON 字符串（跨 world 传对象最稳的形式）。
 */
(() => {
  'use strict';

  const W = window;
  if (W.__ceHooked) return;
  try {
    Object.defineProperty(W, '__ceHooked', { value: 1, enumerable: false, configurable: false });
  } catch (_) {
    return;
  }

  const EVT = 'ce:config';

  /** @type {{items:any[], mode:number, ear8?:any[]}|null} */
  let CFG = null;
  /** 从 Google 自己的响应里顺手抓到的当前订阅 ID（24 位小写） */
  let SUB_ID = null;

  document.addEventListener(
    EVT,
    (ev) => {
      try {
        const raw = ev.detail;
        const d = typeof raw === 'string' ? JSON.parse(raw) : raw;
        if (!d || !Array.isArray(d.items)) return;
        CFG = d;
        if (typeof d.subId === 'string' && d.subId) SUB_ID = d.subId;
      } catch (_) {}
    },
    true
  );

  const curMode = () => (CFG && Number(CFG.mode)) || 5;

  function ear8() {
    if (CFG && Array.isArray(CFG.ear8)) return CFG.ear8;
    if (SUB_ID) return [null, curMode(), null, null, null, [SUB_ID]];
    return null;
  }

  /* ---------- 1. Ngbm（one.google.com 的 batchexecute 报价 RPC） ---------- */

  function patchTargetNode(node) {
    if (!Array.isArray(node) || !CFG || !Array.isArray(CFG.items)) return false;
    let patched = false;

    if (node.length > 12 && Array.isArray(node[12])) {
      if (Array.isArray(node[7]) && Array.isArray(node[7][5]) && node[7][5].length > 0) {
        SUB_ID = node[7][5][0];
      }
      node[12] = CFG.items;
      const e8 = ear8();
      if (e8) {
        node[7] = e8;
      } else if (Array.isArray(node[7]) && Array.isArray(node[7][5]) && node[7][5].length > 0) {
        node[7][1] = curMode();
      } else if (SUB_ID) {
        node[7] = [null, curMode(), null, null, null, [SUB_ID]];
      }
      patched = true;
    }

    if (node.length > 10 && Array.isArray(node[10]) && Array.isArray(node[10][0])) {
      node[10] = [CFG.items];
      if (Array.isArray(node[2]) && Array.isArray(node[2][2]) && Array.isArray(node[2][2][8])) {
        node[2][2][8] = [CFG.items];
      }
      const e8 = ear8();
      if (e8) node[6] = e8;
      patched = true;
    }
    return patched;
  }

  function rewriteFreq(bodyStr) {
    if (typeof bodyStr !== 'string' || bodyStr.indexOf('f.req=') === -1 || !CFG) return bodyStr;
    try {
      const parts = bodyStr.split('&');
      for (let i = 0; i < parts.length; i++) {
        if (!parts[i].startsWith('f.req=')) continue;
        const raw = decodeURIComponent(parts[i].slice(6).replace(/\+/g, ' '));
        const outer = JSON.parse(raw);
        let changed = false;
        if (Array.isArray(outer)) {
          for (const group of outer) {
            if (!Array.isArray(group)) continue;
            for (const call of group) {
              if (!Array.isArray(call) || call[0] !== 'Ngbm' || typeof call[1] !== 'string') continue;
              const payload = JSON.parse(call[1]);
              if (Array.isArray(payload)) {
                if (patchTargetNode(payload[0])) changed = true;
                if (patchTargetNode(payload[1])) changed = true;
              }
              if (changed) call[1] = JSON.stringify(payload);
            }
          }
        }
        if (changed) {
          parts[i] = 'f.req=' + encodeURIComponent(JSON.stringify(outer));
          return parts.join('&');
        }
        return bodyStr;
      }
    } catch (_) {}
    return bodyStr;
  }

  /* ---------- 2. /eacquire/multiline?ear=... ---------- */

  function rewriteUrl(val) {
    const s = String(val || '');
    if (s.indexOf('/eacquire/multiline') === -1 || !CFG) return val;
    try {
      const u = new URL(s, location.origin);
      const earStr = u.searchParams.get('ear');
      if (!earStr) return val;
      const ear = JSON.parse(earStr);

      if (Array.isArray(ear[8]) && Array.isArray(ear[8][5]) && ear[8][5].length > 0) {
        SUB_ID = ear[8][5][0];
      }
      if (Array.isArray(ear[13]) && Array.isArray(CFG.items)) {
        ear[13][0] = CFG.items;
      }
      if (Array.isArray(ear[4]) && typeof ear[4][0] === 'string' && Array.isArray(CFG.items)) {
        try {
          const inner4 = JSON.parse(atob(ear[4][0]));
          if (Array.isArray(inner4) && inner4.length > 8) {
            inner4[8] = [CFG.items];
            ear[4][0] = btoa(JSON.stringify(inner4));
          }
        } catch (_) {}
      }
      const e8 = ear8();
      if (e8) {
        ear[8] = e8;
      } else if (Array.isArray(ear[8]) && Array.isArray(ear[8][5]) && ear[8][5].length > 0) {
        ear[8][1] = curMode();
      } else if (SUB_ID) {
        ear[8] = [null, curMode(), null, null, null, [SUB_ID]];
      }
      ear[24] = null;

      u.searchParams.set('ear', JSON.stringify(ear));
      return u.toString();
    } catch (_) {
      return val;
    }
  }

  /* ---------- 3. 抓包：把 eacquire / batchexecute 的响应回吐给面板 ---------- */
  /*
   * 结账失败时 Google 只会给一句「出了点问题」，真正的原因在响应 JSON 的 code 里
   * （形如 OR-HDT-01 / BX-CPL-05 / DF-DFERH-01）。这里把响应体截一段通过
   * CustomEvent 送到 ISOLATED world，再由 content script 转发给 bg 打到面板日志。
   */
  function isInteresting(url) {
    const s = String(url || '');
    return s.indexOf('eacquire') !== -1 || s.indexOf('Ngbm') !== -1 || s.indexOf('batchexecute') !== -1;
  }

  function emitProbe(kind, url, status, body) {
    try {
      document.dispatchEvent(
        new CustomEvent('ce:probe', {
          detail: JSON.stringify({
            kind,
            url: String(url || '').slice(0, 320),
            status: status || 0,
            snippet: String(body || '').slice(0, 3000),
          }),
        })
      );
    } catch (_) {}
  }

  /* ---------- 4. 安装各类钩子 ---------- */

  // 4.1 XHR
  const origXhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    try {
      this.__ceUrl = String(url);
    } catch (_) {}
    return origXhrOpen.call(this, method, url, ...rest);
  };

  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (typeof body === 'string' && body.indexOf('Ngbm') !== -1) body = rewriteFreq(body);
    } catch (_) {}

    try {
      if (isInteresting(this.__ceUrl) && !this.__ceProbe) {
        this.__ceProbe = 1;
        this.addEventListener('loadend', () => {
          let t = '';
          try {
            if (this.responseType === '' || this.responseType === 'text') t = this.responseText;
          } catch (_) {}
          emitProbe('xhr', this.__ceUrl, this.status, t);
        });
      }
    } catch (_) {}
    return origSend.call(this, body);
  };

  // 4.2 fetch（新版 one.google.com 有部分 RPC 走 fetch，原脚本只钩了 XHR，这里补齐）
  const origFetch = W.fetch;
  if (typeof origFetch === 'function') {
    W.fetch = function (input, init) {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      try {
        if (init && typeof init.body === 'string' && init.body.indexOf('Ngbm') !== -1) {
          init = Object.assign({}, init, { body: rewriteFreq(init.body) });
        }
      } catch (_) {}

      const p = origFetch.call(this, input, init);
      if (isInteresting(url) && p && typeof p.then === 'function') {
        p.then((res) => {
          try {
            res
              .clone()
              .text()
              .then((t) => emitProbe('fetch', url, res.status, t))
              .catch(() => {});
          } catch (_) {}
        }).catch(() => {});
      }
      return p;
    };
  }

  // 4.3 URL.createObjectURL（部分 iframe 用 blob 承载 cheout URL）
  const origCreateObjectURL = URL.createObjectURL;
  if (typeof origCreateObjectURL === 'function') {
    URL.createObjectURL = function (obj) {
      const url = origCreateObjectURL.call(URL, obj);
      return CFG ? rewriteUrl(url) : url;
    };
  }

  // 4.4 Trusted Types（Google 开了 TT，普通字符串赋值会被拒）
  if (W.TrustedTypePolicy && TrustedTypePolicy.prototype.createScriptURL) {
    const origCreate = TrustedTypePolicy.prototype.createScriptURL;
    TrustedTypePolicy.prototype.createScriptURL = function (input, ...args) {
      return origCreate.call(this, rewriteUrl(input), ...args);
    };
  }

  // 4.5 iframe.src setter
  const srcDesc = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'src');
  if (srcDesc && srcDesc.set) {
    Object.defineProperty(HTMLIFrameElement.prototype, 'src', {
      ...srcDesc,
      set(v) {
        if (typeof v === 'string') v = rewriteUrl(v);
        return srcDesc.set.call(this, v);
      },
    });
  }

  // 4.6 setAttribute('src', ...)
  const origSetAttr = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function (name, val) {
    try {
      if (this instanceof HTMLIFrameElement && String(name).toLowerCase() === 'src') {
        val = rewriteUrl(String(val));
      }
    } catch (_) {}
    return origSetAttr.call(this, name, val);
  };

  // 4.7 window.open（少数流程直接开新窗口去结账）
  const origOpen = W.open;
  if (typeof origOpen === 'function') {
    W.open = function (url, ...rest) {
      try {
        if (typeof url === 'string') url = rewriteUrl(url);
      } catch (_) {}
      return origOpen.call(W, url, ...rest);
    };
  }
})();
