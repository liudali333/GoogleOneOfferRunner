/*
 * 作者 Sky | TG 群: Geminivip1
 * 扩展：Google One Offer Runner v1.1.0
 * 请勿删除本署名；二次分发请保留作者信息。
 */
/* popup.js — 面板逻辑（MV3 CSP：不能写内联脚本，全部走这里） */
const CFG_KEY = 'ce.config';

const DEFAULT_TOKENS = {
  L12M: 'AVbCH/cspB8VdqKJ+ax/uPxUFAVuYRPX4iSjtg4Fu0PG9zUeURSM7y//LlQva1dCd/rbKVM6EJmyiG/C9BoQ95pMl8yDCHuiwCvM5CuGJME=',
  L6M_SS: 'AVbCH/cgl4zvPT2Lqw95Gn+RYAJIVwFwi783i6uVprX7u3MCa5J4CcTXH5RABa5WjBrUoQnwf8vI10TNV7ktd26myIdxqIwGmNoJ5ofYNqpQ10RKoSvHs75wsfA=',
  L6M: 'AVbCH/fUON3w8hpfeutprA3BMQwrBwYIB6Y8CSWi1isDCDswKUUhGQ3dluj5WXsNKOvr8K5UULBGrRsf4KlW1rHLz0fF3SvxQhBFRbBOHCA=',
  L6M_2: 'AVbCH/cJ5SeHgkVRt+bdcrapx/aLSu2kbsBgMdI413zbllDNsNQoC/zVlG/Npbu55WlMzBwWPhUedIvZFDg7fw0CmCv/8DKj04IZ21pK7mrV/hh5',
  YT: 'AVbCH/eW4Nfp8KBl0zlm7x9PhaiCvpnqwUuL2D8NFPBQgmM9+HuYS1h2xH5lLWU/BsBj775LK5GqK8UHKqoSzhDDz+PqP3paNesqLU0r9i6XCrYa',
};

const $ = (id) => document.getElementById(id);

let saveTimer = null;
let lastLogLen = 0;

/* ---------- 读写配置 ---------- */
async function loadCfg() {
  const d = await chrome.storage.local.get(CFG_KEY);
  return d[CFG_KEY] || {};
}

async function saveCfg(patch) {
  const cur = await loadCfg();
  const next = Object.assign({}, cur, patch);
  await chrome.storage.local.set({ [CFG_KEY]: next });
  return next;
}

/** 只保留需要的字段；老版本存过的 card 原样带着不动（结账 iframe 里仍可自动填卡） */
function readForm() {
  const tokens = {
    L12M: $('t_L12M').value.trim(),
    L6M_SS: $('t_L6M_SS').value.trim(),
    L6M: $('t_L6M').value.trim(),
    L6M_2: $('t_L6M_2').value.trim(),
    YT: $('t_YT').value.trim(),
  };
  return {
    tokens,
    zeroCostGate: $('optGate').checked,
    autoCancel: $('optCancel').checked,
  };
}

function fillForm(cfg) {
  const t = Object.assign({}, DEFAULT_TOKENS, cfg.tokens || {});
  $('t_L12M').value = t.L12M;
  $('t_L6M_SS').value = t.L6M_SS;
  $('t_L6M').value = t.L6M;
  $('t_L6M_2').value = t.L6M_2;
  $('t_YT').value = t.YT;

  $('optGate').checked = cfg.zeroCostGate !== false;
  $('optCancel').checked = cfg.autoCancel === true;
}

function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => saveCfg(readForm()), 350);
}

/* ---------- 状态渲染 ---------- */
function renderState(state) {
  const s = (state && state.session) || {};
  const dot = $('dot');
  dot.className = 'dot';
  if (s.running) dot.classList.add('run');
  else if (s.phase === 'done') dot.classList.add('ok');
  else if (s.phase === 'failed') dot.classList.add('err');

  const map = {
    idle: '空闲',
    armed: '已注入，等待结账弹窗',
    checkout: '结账弹窗处理中',
    gating: '0 元闸门判断中',
    buying: '正在点击订阅',
    cancel: '取消续订中',
    done: '完成',
    failed: '失败',
  };
  $('status').textContent = (s.layer ? `L${s.layer} · ` : '') + (map[s.phase] || s.phase || '空闲');

  document.querySelectorAll('button.layer').forEach((b) => {
    b.disabled = !!s.running;
  });

  const logs = s.logs || [];
  if (logs.length !== lastLogLen) {
    lastLogLen = logs.length;
    const el = $('log');
    el.textContent = logs.join('\n');
    el.scrollTop = el.scrollHeight;
  }
}

async function refresh() {
  try {
    renderState(await chrome.runtime.sendMessage({ type: 'GET_STATE' }));
  } catch (_) {}
}

/* ---------- 事件 ---------- */
document.querySelectorAll('button.layer').forEach((btn) => {
  btn.addEventListener('click', async () => {
    await saveCfg(readForm());
    const layer = Number(btn.dataset.layer);
    btn.disabled = true;
    const r = await chrome.runtime.sendMessage({ type: 'RUN', layer });
    if (r && r.ok === false) {
      const reasons = { busy: '已有任务在跑', 'wrong-tab': '当前标签页不是 one.google.com' };
      $('status').textContent = '未启动：' + (reasons[r.reason] || r.reason);
      btn.disabled = false;
    }
    refresh();
  });
});

$('btnCancel').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'CANCEL' });
  refresh();
});

$('btnReset').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'RESET' });
  lastLogLen = 0;
  $('log').textContent = '';
  refresh();
});

$('btnPlans').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'OPEN_PLANS' });
  window.close();
});

$('btnResetTok').addEventListener('click', async () => {
  Object.entries(DEFAULT_TOKENS).forEach(([k, v]) => {
    $('t_' + k).value = v;
  });
  await saveCfg(readForm());
});

$('btnClearLog').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'RESET' });
  lastLogLen = 0;
  $('log').textContent = '';
});

['t_L12M', 't_L6M_SS', 't_L6M', 't_L6M_2', 't_YT'].forEach((id) => $(id).addEventListener('input', scheduleSave));
['optGate', 'optCancel'].forEach((id) => $(id).addEventListener('change', scheduleSave));

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'STATE_PUSH') refresh();
});

/* ---------- 启动 ---------- */
(async () => {
  fillForm(await loadCfg());
  await refresh();
  setInterval(refresh, 900);
})();
