@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ================================================
echo  Google One Offer Runner - 安装环境自检
echo ================================================
echo.

set ERR=0

echo [1/5] 检查当前目录...
if exist "manifest.json" (
  echo     OK  找到 manifest.json
) else (
  echo     FAIL 这个目录里没有 manifest.json
  echo          你现在在: %CD%
  echo.
  echo     >>> 这就是 Chrome 报「清单文件缺失」的原因。
  echo     >>> 请进入下一层文件夹，直到能看见 manifest.json 为止。
  dir /b /ad 2>nul
  set ERR=1
)
echo.

if "%ERR%"=="1" goto :done

echo [2/5] 检查必备文件是否齐全...
for %%f in (bg.js manifest.json) do (
  if exist "%%f" (echo     OK  %%f) else (echo     FAIL 缺少 %%f & set ERR=1)
)
for %%d in (inject content popup) do (
  if exist "%%d\" (echo     OK  %%d\) else (echo     FAIL 缺少 %%d\ & set ERR=1)
)
echo.

echo [3/5] 检查是否存在「套娃」目录...
if exist "extension\manifest.json" (
  echo     WARN 发现 extension\manifest.json
  echo          外层多余了一层，应选里面的 extension 目录。
)
if exist "GoogleOneOfferRunner\manifest.json" (
  echo     WARN 发现 GoogleOneOfferRunner\manifest.json
  echo          外层多余了一层，应选里面的 GoogleOneOfferRunner 目录。
)
if not exist "extension\manifest.json" if not exist "GoogleOneOfferRunner\manifest.json" echo     OK  层级正常
echo.

echo [4/5] 校验 manifest.json 是否是合法 JSON...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { $m = Get-Content -Raw -Encoding UTF8 'manifest.json' | ConvertFrom-Json; Write-Host ('     OK  name=' + $m.name + '  version=' + $m.version + '  v' + $m.manifest_version) } catch { Write-Host ('     FAIL JSON 解析失败: ' + $_.Exception.Message); exit 1 }"
if errorlevel 1 set ERR=1
echo.

echo [5/5] 检查文件是否被「网络来源」标记 / 被改名...
dir /r 2>nul | findstr /i "Zone.Identifier" >nul && (
  echo     WARN 文件带 Zone.Identifier（从网络下载的标记）
  echo          一般不影响加载，若报错可右键 zip - 属性 - 勾「解除锁定」后再解压
) || echo     OK  没有网络锁定标记
if exist "manifest.json.txt" (
  echo     FAIL 发现 manifest.json.txt —— 扩展名被改了，改回 manifest.json
  set ERR=1
)
echo.

:done
echo ================================================
if "%ERR%"=="1" (
  echo  结果: 有问题，按上面提示处理
) else (
  echo  结果: 全绿，可以去 chrome://extensions 加载这个文件夹
  echo        地址栏输入: chrome://extensions
)
echo ================================================
echo.
echo 作者 Sky ^| TG 群: Geminivip1
echo.
pause
