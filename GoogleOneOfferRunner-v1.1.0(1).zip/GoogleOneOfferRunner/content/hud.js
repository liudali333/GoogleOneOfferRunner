/*
 * 作者 Sky | TG 群: Geminivip1
 * 扩展：Google One Offer Runner v1.1.0
 * 请勿删除本署名；二次分发请保留作者信息。
 */
/*
 * content/hud.js — 页面悬浮窗（作者水印 + 实时状态 HUD）
 *
 * 只在顶层 frame 跑，样式由 manifest 的 content_scripts.css 注入
 * （走 Chrome 的注入通道，不受页面 CSP 影响）。
 *
 * 功能：
 *   · 左下/右下常驻，醒目显示作者与 TG 群
 *   · 实时显示当前阶段（已注入 / 结账中 / 点击订阅 / 完成 / 失败）
 *   · 可拖动、可收起，位置记在本机
 */
(() => {
  'use strict';
  if (window.top !== window) return;
  if (document.getElementById('skyhud')) return;

  const AUTHOR = { name: 'Sky', tg: 'Geminivip1', url: 'https://t.me/Geminivip1' };
  const POS_KEY = 'ce.hud';
  const PHASE_TXT = {
    idle: '空闲',
    armed: '已注入',
    checkout: '结账中',
    gating: '闸门判断',
    buying: '点击订阅',
    cancel: '取消续订',
    done: '完成',
    failed: '失败',
  };

  const host = document.createElement('div');
  host.id = 'skyhud';
  host.className = 'skyhud';
  host.innerHTML = `
    <div class="skyhud-ico" title="${AUTHOR.name} · TG 群 ${AUTHOR.tg}">S</div>
    <div class="skyhud-body">
      <div class="skyhud-name">${AUTHOR.name}</div>
      <a class="skyhud-tg" href="${AUTHOR.url}" target="_blank" rel="noreferrer">TG 群 ${AUTHOR.tg}</a>
    </div>
    <div class="skyhud-stat">
      <span class="skyhud-dot"></span>
      <span class="skyhud-phase">空闲</span>
    </div>
    <button class="skyhud-min" title="收起 / 展开">−</button>
  `;

  const $ico = host.querySelector('.skyhud-ico');
  const $dot = host.querySelector('.skyhud-dot');
  const $phase = host.querySelector('.skyhud-phase');
  const $min = host.querySelector('.skyhud-min');
  const $tg = host.querySelector('.skyhud-tg');

  /* ---------- 拖动 ---------- */
  let dragging = false;
  let moved = false;
  let offX = 0;
  let offY = 0;

  host.addEventListener('pointerdown', (e) => {
    if (e.target === $tg || e.target === $min) return; // 链接和按钮不触发拖动
    dragging = true;
    moved = false;
    const r = host.getBoundingClientRect();
    offX = e.clientX - r.left;
    offY = e.clientY - r.top;
    host.classList.add('skyhud-dragging');
    host.setPointerCapture?.(e.pointerId);
  });

  host.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    moved = true;
    const x = Math.max(4, Math.min(window.innerWidth - host.offsetWidth - 4, e.clientX - offX));
    const y = Math.max(4, Math.min(window.innerHeight - host.offsetHeight - 4, e.clientY - offY));
    host.style.setProperty('left', x + 'px', 'important');
    host.style.setProperty('top', y + 'px', 'important');
    host.style.setProperty('right', 'auto', 'important');
    host.style.setProperty('bottom', 'auto', 'important');
  });

  const endDrag = () => {
    if (!dragging) return;
    dragging = false;
    host.classList.remove('skyhud-dragging');
    if (moved) {
      const r = host.getBoundingClientRect();
      try {
        chrome.storage.local.set({ [POS_KEY]: { left: Math.round(r.left), top: Math.round(r.top) } });
      } catch (_) {}
    }
  };
  host.addEventListener('pointerup', endDrag);
  host.addEventListener('pointercancel', endDrag);

  /* ---------- 收起 / 展开 ---------- */
  const toggle = (force) => {
    const collapsed = force === undefined ? !host.classList.contains('skyhud-collapsed') : force;
    host.classList.toggle('skyhud-collapsed', collapsed);
    $min.textContent = collapsed ? '+' : '−';
    try {
      chrome.storage.local.set({ [POS_KEY + '.collapsed']: collapsed });
    } catch (_) {}
  };
  $min.addEventListener('click', (e) => {
    e.stopPropagation();
    toggle();
  });
  // 收起后点图标展开
  $ico.addEventListener('click', () => {
    if (host.classList.contains('skyhud-collapsed')) toggle(false);
  });
  // 别让点击穿透到页面
  host.addEventListener('click', (e) => e.stopPropagation());

  /* ---------- 状态轮询 ---------- */
  async function tick() {
    try {
      const st = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
      const s = (st && st.session) || {};
      $dot.className = 'skyhud-dot';
      if (s.running) $dot.classList.add('run');
      else if (s.phase === 'done') $dot.classList.add('ok');
      else if (s.phase === 'failed') $dot.classList.add('err');
      const txt = (s.layer ? 'L' + s.layer + ' · ' : '') + (PHASE_TXT[s.phase] || '空闲');
      if ($phase.textContent !== txt) $phase.textContent = txt;
    } catch (_) {
      // 扩展被 reload 后上下文失效，安静退出
    }
  }

  /* ---------- 挂载 ---------- */
  function mount() {
    if (!document.body) return setTimeout(mount, 200);
    document.body.appendChild(host);
    try {
      chrome.storage.local.get([POS_KEY, POS_KEY + '.collapsed'], (d) => {
        const p = d[POS_KEY];
        if (p && typeof p.left === 'number') {
          host.style.setProperty('left', p.left + 'px', 'important');
          host.style.setProperty('top', p.top + 'px', 'important');
          host.style.setProperty('right', 'auto', 'important');
          host.style.setProperty('bottom', 'auto', 'important');
        }
        if (d[POS_KEY + '.collapsed']) toggle(true);
      });
    } catch (_) {}
    tick();
    setInterval(tick, 1500);
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') mount();
  else document.addEventListener('DOMContentLoaded', mount, { once: true });
})();
