/*
 * 作者 Sky | TG 群: Geminivip1
 * 扩展：Google One Offer Runner v1.0.0
 * 请勿删除本署名；二次分发请保留作者信息。
 */
/*
 * content/driver.js — ISOLATED world，只在 one.google.com 顶层 frame 跑
 *
 * 职责：
 *   1) 收到 background 的 ARM 指令 → 把 offer 条目推给 hook（等价原脚本的 __setDirectTest）
 *   2) 点方案页上那个「开始使用 / 获取优惠 / 升级」按钮，把 Play 结账弹窗拉起来
 *   3) 结账弹窗内部的活儿交给 content/play.js（它跑在 play.google.com 那个 iframe 里）
 *   4) 收尾：把标签页导到订阅管理页，让 play.js 完成取消续订
 */
(() => {
  'use strict';
  if (window.top !== window) return; // 只在顶层

  const C = globalThis.CE;
  let busy = false;

  const ACTION_LABELS = [
    '开始使用',
    '获取优惠',
    '获取折扣',
    '换用此方案',
    '更改方案',
    '更改计划',
    '切换方案',
    '切换计划',
    '升级',
    'Upgrade',
    '获取 Google AI Ultra',
    'Get started',
    'Get offer',
    'Switch to this plan',
    'Change plan',
    'Switch plan',
  ];

  /** 点方案按钮，最多试 10 次（React 首屏渲染有延迟） */
  async function clickPlanAction(layer) {
    const hit = await C.waitFor(
      () => {
        const btn = C.findLastByText(ACTION_LABELS);
        if (btn) {
          C.hardClick(btn);
          return { text: C.text(btn).slice(0, 40) };
        }
        // 兜底：方案卡里 role=button 的「获取」类元素
        const alt = C.findByText(['获取', 'Get'], { root: document });
        if (alt && C.visible(alt)) {
          C.hardClick(alt);
          return { text: C.text(alt).slice(0, 40) };
        }
        return null;
      },
      { timeout: 15000, interval: 1200 }
    );
    if (hit) C.log(`[L${layer}] 已点【${hit.text}】`, 'ok');
    return hit;
  }

  /** 等结账 iframe 出现（说明 hook 的 ear 改写生效了） */
  async function waitCheckoutFrame(timeout = 45000) {
    return C.waitFor(
      () => Array.from(document.querySelectorAll('iframe')).find((f) => /eacquire|instrument|fop/i.test(f.src || '')),
      { timeout, interval: 500 }
    );
  }

  async function runLayer(layer) {
    if (busy) {
      C.log('已有任务在跑，忽略重复指令', 'warn');
      return;
    }
    busy = true;
    const C2 = globalThis.CE;
    try {
      const cfg = await C2.loadCfg();
      const items = C2.buildItems(cfg, layer);
      if (!items.length) {
        C.report('RUN_FAILED', { layer, reason: '该层没有可用 token，请先在 popup 里填/换 token' });
        return;
      }

      // ⚠️ 不要自己 location.href —— 跳转会销毁本 content script 的上下文，
      // 后面的点击逻辑永远执行不到（表现为"只导航、没反应"）。
      // 交给 bg 导航，它不会被页面卸载杀掉。
      // 注意：/plans 会被 Google 302 到 /settings?expand=upgrade，两者都算方案页
      if (!/one\.google\.com\/(plans|settings)/.test(location.href)) {
        C.log(`[L${layer}] 当前不在方案页（${location.pathname}），请后台重新导航`, 'warn');
        C.report('NEED_NAV', { layer });
        return;
      }

      for (let attempt = 1; attempt <= 2; attempt++) {
        // 先把 items 推给 hook（不等订阅 ID，别拖时间）
        let subId = C2.scrapeSubId();
        C2.armHook(items, subId);
        // 立刻给一行反馈：否则等订阅 ID 的这段时间面板是静默的，看起来像"卡住了"
        C.log(`[L${layer}] 已注入 ${items.length} 个条目${subId ? '' : '，等订阅 ID（最多 6s）…'}`, 'info');

        // 页面指纹：出问题时这三项能立刻判断"页面状态对不对"
        try {
          const bt = document.body ? document.body.innerText : '';
          C.log(
            `[L${layer}] 页面状态: ${/当前方案|Current plan/i.test(bt) ? '有当前方案' : '无当前方案'} ｜ ` +
              `${/升级|更改方案|切换|Upgrade|Change plan/i.test(bt) ? '有升级入口' : '无升级入口'} ｜ ` +
              `${/AI Pro|AI Ultra|Google One/i.test(bt) ? '显示套餐卡' : '未显示套餐卡'}`,
            'info'
          );
        } catch (_) {}

        // 叠加场景（L2/L3）必须带真实订阅 ID：页面渲染出来要几秒，这里最多等 6s
        if (!subId) {
          subId = await C2.waitFor(() => C2.scrapeSubId(), { timeout: 6000, interval: 500 });
        }
        C.log(
          subId ? `订阅 ID: ${subId}（走 mode 5 叠加）` : '页面上没有活跃订阅 ID，交给 hook 动态捕获（首购路径）',
          subId ? 'info' : 'warn'
        );
        C.log(`[L${layer}] 第 ${attempt}/2 次尝试开始点击`, 'info');

        // 补发一次，确保 hook 拿到最终版（含 subId）
        await C.sleep(400);
        C2.armHook(items, subId);

        const clicked = await clickPlanAction(layer);
        if (!clicked) {
          const dump = Array.from(document.querySelectorAll('button, a, [role="button"]'))
            .filter((e) => C.visible(e))
            .map((e) => C.text(e) || e.getAttribute('aria-label') || '')
            .filter((t) => t && t.length <= 24)
            .slice(0, 24);
          C.log(`[L${layer}] 没找到可点的方案按钮。当前 URL: ${location.href.slice(0, 90)}`, 'warn');
          C.log(`[L${layer}] 页面上可点的文案: ${dump.join(' / ') || '(空，页面可能还没渲染完)'}`, 'warn');
          await C.sleep(1500);
          continue;
        }

        C.report('CHECKOUT_WAIT', { layer, attempt });
        const frame = await waitCheckoutFrame(50000);
        if (frame) {
          C.log(`[L${layer}] Play 结账弹窗已出现，交给 play.js 处理`, 'ok');
          C.report('CHECKOUT_FRAME', { layer, attempt, src: frame.src.slice(0, 160) });
          return; // 后续由 play.js 汇报 BUY_RESULT
        }
        const ifr = Array.from(document.querySelectorAll('iframe'))
          .map((f) => (f.src || '(no src)').slice(0, 110))
          .slice(0, 6);
        C.log(`[L${layer}] 第 ${attempt} 次没等到结账弹窗，重试`, 'warn');
        C.log(
          ifr.length ? `[L${layer}] 当前页面 iframe(${ifr.length}): ${ifr.join(' ｜ ')}` : `[L${layer}] 当前页面没有任何 iframe（结账可能没被触发）`,
          'warn'
        );
        C.log(`[L${layer}] 当前 URL: ${location.href.slice(0, 110)}`, 'warn');
        await C.sleep(3000);
      }

      C.report('RUN_FAILED', { layer, reason: '两次尝试都没拉起 Play 结账弹窗（token 失效 / ear 未命中 / 需要重新登录）' });
    } catch (e) {
      C.report('RUN_FAILED', { layer, reason: String(e && e.message) });
    } finally {
      busy = false;
    }
  }

  /* ---------- 收尾：取消自动续订 ---------- */
  async function goCancel() {
    const cfg = await C.loadCfg();
    if (cfg.autoCancel === false) {
      C.log('配置里关闭了自动取消，跳过', 'info');
      return;
    }
    C.log('前往订阅管理页，准备取消自动续订', 'info');
    location.href = 'https://play.google.com/store/account/subscriptions?hl=zh-CN';
  }

  /* ---------- 消息入口 ---------- */
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg.type !== 'string') return;

    if (msg.type === 'ARM') {
      runLayer(msg.layer).then(() => sendResponse({ ok: true }));
      return true;
    }
    if (msg.type === 'GO_CANCEL') {
      goCancel().then(() => sendResponse({ ok: true }));
      return true;
    }
    if (msg.type === 'PING') {
      sendResponse({ ok: true, href: location.href, ready: true });
      return true;
    }
  });

  // 页面可能带着 #/plans 之类进来，登录态被弹走时提示一下
  window.addEventListener(
    'load',
    () => {
      if (location.hostname !== 'one.google.com') return;
      if (/accounts\.google\.com|gds\.google\.com/.test(location.href)) {
        C.log('被跳到登录/二次验证页，请先手动登录目标账号', 'warn');
      }
    },
    { once: true }
  );

  // 把 hook 抓到的 Ngbm 响应吐给面板（结账失败时真因就在里面）
  C.onProbe((info) => {
    C.report('PROBE', {
      kind: info.kind,
      url: info.url,
      status: info.status,
      snippet: info.snippet,
      codes: C.extractCodes(info.snippet),
    });
  });

  C.log('driver 已就绪（one.google.com）', 'ok');
})();
