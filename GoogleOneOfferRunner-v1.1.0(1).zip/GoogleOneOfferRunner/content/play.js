/*
 * 作者 Sky | TG 群: Geminivip1
 * 扩展：Google One Offer Runner v1.0.0
 * 请勿删除本署名；二次分发请保留作者信息。
 */
/*
 * content/play.js — ISOLATED world，play.google.com 的**所有** frame
 *
 * 这是整个方案能替掉 Playwright 的关键：
 * Play 结账弹窗是 one.google.com 里嵌的 play.google.com 跨域 iframe，
 * 父页面碰不到它的 DOM，但扩展可以给这个 iframe 单独注册 content script，
 * 于是「读弹窗文案 / 判断是不是 0.00 / 点订阅 / 填卡 / 填 CVC」全都在 iframe 内部完成。
 *
 * 两种角色按 URL 自动分派：
 *   /eacquire/ , /instrument/ , /fop/  → 结账弹窗
 *   /store/account/subscriptions       → 订阅管理（取消续订）
 */
(() => {
  'use strict';
  const C = globalThis.CE;
  const HERE = location.href;

  const IS_CHECKOUT = /eacquire|instrument|fop|\/fop\/|purchase/i.test(HERE);
  const IS_SUBS_PAGE = /play\.google\.com\/store\/account\/subscriptions/i.test(HERE);

  if (!IS_CHECKOUT && !IS_SUBS_PAGE) return;

  const ADD_CARD_LABELS = [
    '添加付款方式',
    '首先添加付款方式',
    '添加信用卡或借记卡',
    '添加卡',
    'Add a payment method',
    'Add credit or debit card',
    'Add card',
  ];
  const BUY_LABELS = [
    '订阅',
    '购买',
    '确认购买',
    '立即订阅',
    '订阅并支付',
    '开始试用',
    '免费试用',
    '继续',
    'Subscribe',
    'Buy',
    'Confirm',
    'Start free trial',
    'Try free',
  ];
  const SUCCESS_LABELS = ['欢迎您', '新会员已生效', '已订阅', '您已订阅', 'Play 积分', 'Welcome', 'You are subscribed'];
  const ERROR_LABELS = [
    '错误',
    '出了点问题',
    '无法更改',
    '购买失败',
    'Something went wrong',
    'unable to change',
    'Your order was not completed',
    'OR-',
    'BX-',
  ];

  const pageText = () => C.pageText();
  const hasAny = (txt, arr) => arr.some((k) => txt.includes(k));

  /* ================= 结账弹窗 ================= */

  /** 把卡从 storage 填进结账 iframe 的表单 */
  async function fillCard() {
    const cfg = await C.loadCfg();
    const card = cfg.card || {};
    const num = String(card.number || '').replace(/\s+/g, '');
    if (num.length < 12) {
      C.log('未保存卡信息，跳过自动填卡（请在结账弹窗里手动填一次，Google 会记住）', 'info');
      return false;
    }

    const inputs = Array.from(document.querySelectorAll('input')).filter((el) => C.visible(el));
    const pick = (re) =>
      inputs.find((el) =>
        re.test(
          [el.name, el.id, el.getAttribute('aria-label'), el.getAttribute('placeholder'), el.getAttribute('autocomplete')]
            .filter(Boolean)
            .join(' ')
        )
      );

    const elNum = pick(/card.?number|cc-number|卡号/i);
    const elExp = pick(/exp|cc-exp|有效期/i);
    const elCvc = pick(/cvc|cvv|security.?code|安全码/i);
    const elName = pick(/holder|name.?on|持卡人|姓名/i);

    if (elNum) {
      C.setInput(elNum, num);
      C.log('已填卡号', 'info');
    }

    // 有效期：Play 常见是 MM/YY 单框，也可能是月/年两个下拉
    if (elExp) {
      const mm = String(card.exp_month || '').padStart(2, '0');
      const yy = String(card.exp_year || '').slice(-2);
      C.setInput(elExp, `${mm}/${yy}`);
      C.log('已填有效期', 'info');
    } else {
      const selects = Array.from(document.querySelectorAll('select')).filter((el) => C.visible(el));
      if (selects[0]) C.setInput(selects[0], String(Number(card.exp_month || 1)).padStart(2, '0'));
      if (selects[1]) C.setInput(selects[1], String(card.exp_year || ''));
    }

    if (elCvc) {
      C.setInput(elCvc, String(card.cvc || ''));
      C.log('已填 CVC', 'info');
    }
    if (elName) C.setInput(elName, String(card.holder || ''));

    // 地址 / 邮编（免税州那条就是靠这里写进去的）
    const addr1 = pick(/address.?line1|street|地址/i);
    const zip = pick(/postal|zip|邮编/i);
    const city = pick(/locality|city|城市/i);
    if (addr1 && card.address_line1) C.setInput(addr1, card.address_line1);
    if (zip && card.postal_code) C.setInput(zip, card.postal_code);
    if (city && card.locality) C.setInput(city, card.locality);

    await C.sleep(600);
    return !!elNum;
  }

  /** 处理「首先添加付款方式」这一支（原脚本的 INLINE_CARD_SAVED_RETRY） */
  async function handleAddCard() {
    const addBtn = C.findByText(ADD_CARD_LABELS);
    if (!addBtn) return false;
    C.log('弹窗要求先加付款方式，正在内联填卡', 'info');
    C.hardClick(addBtn);
    await C.sleep(2500);
    const ok = await fillCard();
    if (!ok) return false;

    // 保存 / 下一步
    const saveBtn = C.findLastByText(['保存', '下一步', '添加', 'Save', 'Next', 'Add']);
    if (saveBtn) {
      C.hardClick(saveBtn);
      await C.sleep(3000);
    }
    C.log('内联绑卡已提交', 'ok');
    return true;
  }

  /** 点「订阅 / 购买」 */
  async function clickBuy() {
    const btn = await C.waitFor(
      () => {
        const b = C.findLastByText(BUY_LABELS);
        return b && C.visible(b) ? b : null;
      },
      { timeout: 20000, interval: 600 }
    );
    if (!btn) {
      C.log('结账弹窗里没找到订阅按钮', 'warn');
      return false;
    }
    C.log(`点击【${C.text(btn).slice(0, 24)}】`, 'info');
    C.hardClick(btn);
    return true;
  }

  /** 买完之后可能出现 CVC 二次验证 */
  async function handleCvcChallenge() {
    const cvcInput = Array.from(document.querySelectorAll('input')).find(
      (el) =>
        C.visible(el) &&
        /cvc|cvv|security.?code|安全码/i.test(
          [el.name, el.id, el.getAttribute('aria-label'), el.getAttribute('placeholder')].filter(Boolean).join(' ')
        )
    );
    if (!cvcInput) return false;
    const cfg = await C.loadCfg();
    C.setInput(cvcInput, String((cfg.card || {}).cvc || ''));
    C.log('已填二次验证 CVC', 'info');
    const okBtn = C.findLastByText(['验证', '确认', '提交', 'Verify', 'Confirm', 'Submit']);
    if (okBtn) C.hardClick(okBtn);
    return true;
  }

  /** 结账流程主循环：上报文案 → 等 bg 的闸门判断 → 点 / 不点 */
  async function checkoutLoop() {
    let reported = false;
    const end = Date.now() + 180000;

    while (Date.now() < end) {
      const txt = pageText();

      // 1) 添加付款方式分支
      if (hasAny(txt, ADD_CARD_LABELS) && !document.querySelector('input[name="cardnumber"], input[autocomplete="cc-number"]')) {
        const done = await handleAddCard();
        if (done) {
          C.report('INLINE_CARD_SAVED', {});
          await C.sleep(2000);
          continue;
        }
      }

      // 2) 首次上报弹窗文案（bg 用它做 0 元闸门判断）
      if (!reported && txt.length > 20) {
        reported = true;
        C.report('CHECKOUT_TEXT', { text: txt.slice(0, 1200) });
      }

      // 3) 已经成功
      if (hasAny(txt, SUCCESS_LABELS)) {
        C.report('BUY_RESULT', { ok: true, text: txt.slice(0, 300) });
        return;
      }
      // 4) 明确失败
      if (hasAny(txt, ERROR_LABELS)) {
        C.report('BUY_RESULT', { ok: false, text: txt.slice(0, 300) });
        return;
      }

      await C.sleep(800);
    }
    C.report('BUY_RESULT', { ok: false, text: '结账弹窗等待超时' });
  }

  /* ================= 订阅管理页：取消续订 ================= */

  async function cancelFlow() {
    C.log('订阅管理页：开始取消自动续订', 'info');
    let txt = await C.waitFor(() => {
      const t = pageText();
      return t.length > 40 ? t : null;
    }, { timeout: 30000 });

    if (!txt) {
      C.report('CANCEL_RESULT', { ok: false, reason: '页面没加载出来' });
      return;
    }
    if (/取消日期|已取消|重新订阅/.test(txt)) {
      C.log('当前已是已取消状态，无需操作', 'ok');
      C.report('CANCEL_RESULT', { ok: true, already: true });
      return;
    }

    // 1) 管理
    const manage = C.findByText(['管理'], { exact: true }) || C.findByText(['Manage'], { exact: true });
    if (manage) {
      C.hardClick(manage);
      await C.sleep(2500);
    }

    // 2) 取消订阅
    const cancel = await C.waitFor(() => C.findByText(['取消订阅'], { exact: true }) || C.findByText(['Cancel subscription'], { exact: true }), {
      timeout: 15000,
      interval: 800,
    });
    if (!cancel) {
      C.report('CANCEL_RESULT', { ok: false, reason: '没找到「取消订阅」入口（可能已是取消态）' });
      return;
    }
    C.hardClick(cancel);
    await C.sleep(2500);

    // 3) 挽留页：不，谢谢
    const noThanks = C.findByText(['不，谢谢', '不用了', 'No thanks', 'No, thanks']);
    if (noThanks) {
      C.hardClick(noThanks);
      await C.sleep(2000);
    }

    // 4) 勾一个原因单选（不选则「继续」是灰的）
    const radios = Array.from(document.querySelectorAll('[role="radio"], input[type="radio"]')).filter((el) => C.visible(el));
    if (radios.length) {
      C.hardClick(radios[radios.length - 1]);
      await C.sleep(600);
    }

    // 5) 继续 / 确认
    for (let i = 0; i < 6; i++) {
      const btn = C.findLastByText(['继续', '确认取消', '确认', 'Continue', 'Confirm']);
      if (btn && C.visible(btn)) {
        C.hardClick(btn);
        await C.sleep(2500);
        break;
      }
      await C.sleep(900);
    }

    // 6) 校验
    txt = await C.waitFor(() => {
      const t = pageText();
      return /取消日期|已取消|重新订阅/.test(t) ? t : null;
    }, { timeout: 20000, interval: 1000 });

    if (txt) {
      C.log('取消成功，已锁死到期日', 'ok');
      C.report('CANCEL_RESULT', { ok: true, text: txt.slice(0, 240) });
    } else {
      C.report('CANCEL_RESULT', { ok: false, reason: '取消后没看到「取消日期」标记' });
    }
  }

  /* ================= 消息入口 ================= */

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg.type !== 'string') return;

    if (msg.type === 'CHECKOUT_GO') {
      if (!IS_CHECKOUT) {
        sendResponse({ ok: false, role: 'not-checkout' });
        return true;
      }
      C.log('收到结账指令，开始读弹窗', 'info');
      checkoutLoop().then(() => sendResponse({ ok: true }));
      return true;
    }
    if (msg.type === 'CLICK_BUY') {
      if (!IS_CHECKOUT) {
        sendResponse({ ok: false });
        return true;
      }
      clickBuy().then(async (ok) => {
        if (ok) await handleCvcChallenge();
        sendResponse({ ok });
      });
      return true;
    }
    if (msg.type === 'CANCEL_GO') {
      if (!IS_SUBS_PAGE) {
        sendResponse({ ok: false, role: 'not-subs' });
        return true;
      }
      cancelFlow().then(() => sendResponse({ ok: true }));
      return true;
    }
    if (msg.type === 'PING') {
      sendResponse({ ok: true, here: HERE, role: IS_CHECKOUT ? 'checkout' : IS_SUBS_PAGE ? 'subs' : 'other' });
      return true;
    }
  });

  C.onProbe((info) => {
    C.report('PROBE', {
      kind: info.kind,
      url: info.url,
      status: info.status,
      snippet: info.snippet,
      codes: C.extractCodes(info.snippet),
    });
  });

  if (IS_CHECKOUT) {
    C.log(`checkout frame 就绪：${HERE.slice(0, 90)}`, 'ok');
    C.report('CHECKOUT_FRAME_READY', {});
  }
  if (IS_SUBS_PAGE) C.log('订阅管理页 content script 就绪', 'ok');
})();
