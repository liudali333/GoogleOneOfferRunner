/*
 * 作者 Sky | TG 群: Geminivip1
 * 扩展：Google One Offer Runner v1.0.0
 * 请勿删除本署名；二次分发请保留作者信息。
 */
/*
 * content/common.js — ISOLATED world 公共层
 * 先于 driver.js / play.js 加载，二者共用这里的常量与工具函数。
 */
'use strict';

/* ---------- 常量：与原 automation_engine.py 完全一致 ---------- */
globalThis.CE = {
  PREFIX: 'subs:com.google.android.apps.subscriptions.red:',
  SKU_AI: 'g1.2tb.ai.subs_variant',
  SKU_YT: 'g1.youtube_premium_individual_add_on',

  // 原件里硬编码的 5 个 offer token（会被 storage 里的值覆盖，popup 可改）
  DEFAULT_TOKENS: {
    L12M: 'AVbCH/cspB8VdqKJ+ax/uPxUFAVuYRPX4iSjtg4Fu0PG9zUeURSM7y//LlQva1dCd/rbKVM6EJmyiG/C9BoQ95pMl8yDCHuiwCvM5CuGJME=',
    L6M_SS: 'AVbCH/cgl4zvPT2Lqw95Gn+RYAJIVwFwi783i6uVprX7u3MCa5J4CcTXH5RABa5WjBrUoQnwf8vI10TNV7ktd26myIdxqIwGmNoJ5ofYNqpQ10RKoSvHs75wsfA=',
    L6M: 'AVbCH/fUON3w8hpfeutprA3BMQwrBwYIB6Y8CSWi1isDCDswKUUhGQ3dluj5WXsNKOvr8K5UULBGrRsf4KlW1rHLz0fF3SvxQhBFRbBOHCA=',
    L6M_2: 'AVbCH/cJ5SeHgkVRt+bdcrapx/aLSu2kbsBgMdI413zbllDNsNQoC/zVlG/Npbu55WlMzBwWPhUedIvZFDg7fw0CmCv/8DKj04IZ21pK7mrV/hh5',
    YT: 'AVbCH/eW4Nfp8KBl0zlm7x9PhaiCvpnqwUuL2D8NFPBQgmM9+HuYS1h2xH5lLWU/BsBj775LK5GqK8UHKqoSzhDDz+PqP3paNesqLU0r9i6XCrYa',
  },

  // 每一层用的 token 槽位 + 人类可读名
  LAYERS: {
    1: { key: 'L12M', label: 'L1 · 12 个月（通用 12M）', months: 12 },
    2: { key: 'L6M_SS', label: 'L2 · 6 个月（S25 / SS 版）', months: 6 },
    3: { key: 'L6M', label: 'L3 · 6 个月（Pixel 版）', months: 6 },
    4: { key: 'L6M_2', label: 'L3b · 6 个月（备用 token）', months: 6 },
  },

  CFG_KEY: 'ce.config',
  SESSION_KEY: 'ce.session',
};

/* ---------- 工具 ---------- */
globalThis.CE.sleep = (ms) => new Promise((r) => setTimeout(r, ms));

globalThis.CE.visible = (el) => {
  if (!el) return false;
  const r = el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return false;
  const st = window.getComputedStyle(el);
  return st.visibility !== 'hidden' && st.display !== 'none' && Number(st.opacity) > 0.01;
};

globalThis.CE.text = (el) => (el.innerText || el.textContent || '').trim();

/** 收集页面上所有可点的元素（含 shadow-free 常规 DOM） */
globalThis.CE.clickables = () =>
  Array.from(document.querySelectorAll('button, a, [role="button"], tp-yt-paper-button, div[jsaction]'));

/** 按文案找第一个可见元素 */
globalThis.CE.findByText = (labels, opts = {}) => {
  const { exact = false, root = document, minSize = true } = opts;
  const nodes = Array.from(
    root.querySelectorAll('button, a, [role="button"], span, div, li, [role="radio"], input[type="radio"]')
  );
  for (const el of nodes) {
    const t = globalThis.CE.text(el);
    if (!t || t.length > 60) continue;
    const hit = labels.some((l) => (exact ? t === l : t.includes(l)));
    if (!hit) continue;
    if (minSize && !globalThis.CE.visible(el)) continue;
    return el;
  }
  return null;
};

/** 找最后一个匹配的按钮（原脚本用的是 btns[btns.length-1]，页面从上到下有多个方案卡） */
globalThis.CE.findLastByText = (labels, opts = {}) => {
  const { root = document } = opts;
  const nodes = Array.from(root.querySelectorAll('button, a, [role="button"]'));
  let hit = null;
  for (const el of nodes) {
    const t = globalThis.CE.text(el);
    if (!t || t.length > 60) continue;
    if (!labels.some((l) => t.includes(l))) continue;
    const r = el.getBoundingClientRect();
    if (r.width <= 15 || r.height <= 15) continue;
    // 原脚本条件：r.left >= 240，排除左侧导航栏的同名按钮
    if (r.left < 240) continue;
    hit = el;
  }
  return hit;
};

/**
 * 点击。合成事件（isTrusted=false）对绝大多数普通监听器有效；
 * 若目标框架校验 isTrusted，用 chrome.debugger 走真实输入（见 README「click() 不生效」）。
 */
globalThis.CE.hardClick = (el) => {
  if (!el) return false;
  try {
    el.scrollIntoView({ block: 'center', inline: 'center' });
  } catch (_) {}
  const r = el.getBoundingClientRect();
  const cx = r.left + r.width / 2;
  const cy = r.top + r.height / 2;
  const base = { bubbles: true, cancelable: true, composed: true, clientX: cx, clientY: cy, view: window };
  try {
    el.dispatchEvent(new PointerEvent('pointerdown', { ...base, pointerId: 1, isPrimary: true }));
    el.dispatchEvent(new MouseEvent('mousedown', base));
    el.dispatchEvent(new PointerEvent('pointerup', { ...base, pointerId: 1, isPrimary: true }));
    el.dispatchEvent(new MouseEvent('mouseup', base));
    el.dispatchEvent(new MouseEvent('click', base));
  } catch (_) {
    try {
      el.click();
    } catch (_) {}
  }
  return true;
};

/** 往 input / textarea 里写值，并触发框架（React/Angular）能识别的事件链 */
globalThis.CE.setInput = (el, value) => {
  if (!el) return false;
  try {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    el.focus();
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Tab' }));
    el.blur();
    return true;
  } catch (_) {
    return false;
  }
};

/** 轮询直到 fn() 返回真值 */
globalThis.CE.waitFor = async (fn, { timeout = 30000, interval = 400 } = {}) => {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    try {
      const v = await fn();
      if (v) return v;
    } catch (_) {}
    await globalThis.CE.sleep(interval);
  }
  return null;
};

/** 整个页面（含跨域 iframe 之外的部分）的可见文本，压成一行 */
globalThis.CE.pageText = () => {
  const t = document.body ? document.body.innerText : '';
  return t.split('\n').map((s) => s.trim()).filter(Boolean).join(' | ');
};

/* ---------- 与 background 通信 ---------- */
globalThis.CE.log = (msg, lvl = 'info') => {
  try {
    chrome.runtime.sendMessage({ type: 'LOG', msg: String(msg), lvl, url: location.href }).catch(() => {});
  } catch (_) {}
};

globalThis.CE.report = (type, payload) => {
  try {
    chrome.runtime.sendMessage({ type, ...payload, url: location.href }).catch(() => {});
  } catch (_) {}
};

/* ---------- 响应抓包（hook.js 在 MAIN world 里发出来的） ---------- */
globalThis.CE.onProbe = (cb) => {
  document.addEventListener(
    'ce:probe',
    (ev) => {
      try {
        cb(JSON.parse(ev.detail));
      } catch (_) {}
    },
    true
  );
};

/** 从响应体里挑出 Google 的错误码，形如 OR-HDT-01 / BX-CPL-05 / DF-DFERH-01 */
globalThis.CE.extractCodes = (text) => {
  const t = String(text || '');
  const out = new Set();
  for (const m of t.matchAll(/\b[A-Z]{2}-[A-Z0-9]{2,}(?:-[A-Z0-9]{2,})*\b/g)) out.add(m[0]);
  return Array.from(out).slice(0, 8);
};

/* ---------- 配置读取 ---------- */
globalThis.CE.loadCfg = async () => {
  const d = await chrome.storage.local.get(globalThis.CE.CFG_KEY);
  return d[globalThis.CE.CFG_KEY] || {};
};

/**
 * 把某一层组装成 Play 购买条目：
 *   [[SKU, 21], null, null, null, 1, [TOKEN]]
 * AI 条目 + YouTube 1 个月试用条目（凑单把总价凑成 0.00，原件也是这么干的）
 */
globalThis.CE.buildItems = (cfg, layer) => {
  const C = globalThis.CE;
  const tokens = Object.assign({}, C.DEFAULT_TOKENS, cfg.tokens || {});
  const slot = (C.LAYERS[layer] || C.LAYERS[1]).key;
  const aiTok = tokens[slot];
  const ytTok = tokens.YT;
  const items = [];
  if (aiTok) items.push([[C.PREFIX + C.SKU_AI, 21], null, null, null, 1, [aiTok]]);
  if (ytTok) items.push([[C.PREFIX + C.SKU_YT, 21], null, null, null, 1, [ytTok]]);
  return items;
};

/** 把配置推进 MAIN world 的 hook（detail 用 JSON 字符串，跨 world 最稳） */
globalThis.CE.armHook = (items, subId) => {
  const detail = JSON.stringify({
    items,
    mode: 5, // 5 = 变更套餐/升级通道，叠加的关键
    subId: subId || null,
  });
  document.dispatchEvent(new CustomEvent('ce:config', { detail }));
};

/**
 * 从页面静态 HTML 里刮 24 位订阅 ID。
 *
 * ⚠️ 只认严格形态：`"<24位小写>.AO-..."` —— 这是 Google 订阅 token 的后缀，取出来的才是真订阅 ID。
 * 绝不能退化成"抓任意 24 位小写串"：新号（还没有订阅）上那样抓到的多半是无关 id，
 * 塞进 ear[8] 会让 Play 收到「改套餐到一个不存在的订阅」，结账直接返回「出了点问题」。
 *
 * 取不到就返回 null，交给 inject/hook.js 从 Google 自己的响应里动态捕获（那条路径才是准的）。
 */
globalThis.CE.scrapeSubId = () => {
  const html = document.documentElement ? document.documentElement.innerHTML : '';
  const m = html.match(/"([a-z]{24})\.AO-/) || html.match(/"([a-z]{24})\.AO-J1O/);
  return m ? m[1] : null;
};
